/* See license.txt for terms of usage */

define(
{
    "root": {
        "aboutTabLabel": "About",
        "schemaTabLabel": "Schema"
    }
});
