/* See license.txt for terms of usage */

define(
{
    "root": {
        "search": "Search",
        "caseSensitive": "Case Sensitive"
    }
});
